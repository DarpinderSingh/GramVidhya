import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import '../core/i18n.dart';
import 'rag.dart';

abstract class LlmBackend {
  String get name;
  Future<bool> available();
  Stream<String> generate(String system, String prompt, {String context = ''});
}

/// Desktop backend: talks to a local Ollama daemon. No internet needed once the model is pulled.
class OllamaBackend implements LlmBackend {
  OllamaBackend({String? model, this.host = 'http://127.0.0.1:11434'})
      : model = model ?? Platform.environment['GRAMVIDYA_OLLAMA_MODEL'] ?? 'llama3.2:3b';
  final String host, model;
  @override
  String get name => 'Ollama · $model';
  @override
  Future<bool> available() async {
    try {
      final r = await http.get(Uri.parse('$host/api/tags')).timeout(const Duration(seconds: 1));
      return r.statusCode == 200 && r.body.contains(model.split(':').first);
    } catch (_) {
      return false;
    }
  }

  @override
  Stream<String> generate(String system, String prompt, {String context = ''}) async* {
    final req = http.Request('POST', Uri.parse('$host/api/chat'))
      ..headers['Content-Type'] = 'application/json'
      ..body = jsonEncode({
        'model': model,
        'stream': true,
        'messages': [
          {'role': 'system', 'content': system},
          {'role': 'user', 'content': prompt},
        ],
      });
    final res = await http.Client().send(req);
    await for (final line in res.stream.transform(utf8.decoder).transform(const LineSplitter())) {
      if (line.trim().isEmpty) continue;
      final j = jsonDecode(line);
      final c = j['message']?['content'];
      if (c is String) yield c;
      if (j['done'] == true) break;
    }
  }
}

/// Android backend: llama.cpp through a platform channel (see native/android/LlamaPlugin.kt).
class NativeLlamaBackend implements LlmBackend {
  static const _m = MethodChannel('gramvidya/llama');
  static const _e = EventChannel('gramvidya/llama/tokens');
  @override
  String get name => 'llama.cpp (on-device)';
  @override
  Future<bool> available() async {
    try {
      return await _m.invokeMethod<bool>('isModelLoaded') ?? false;
    } catch (_) {
      return false;
    }
  }

  @override
  Stream<String> generate(String system, String prompt, {String context = ''}) =>
      _e.receiveBroadcastStream({'system': system, 'prompt': prompt}).cast<String>();
}

/// Always-available fallback: answers from the best retrieved note, no LLM.
class MockBackend implements LlmBackend {
  @override
  String get name => 'Notes-only fallback (no model installed)';
  @override
  Future<bool> available() async => true;
  @override
  Stream<String> generate(String system, String prompt, {String context = ''}) async* {
    final text = context.isEmpty
        ? 'I have no offline notes on that yet. Install a model (see README) or ask a mentor.'
        : 'From your offline notes: ${context.split('\n').first}';
    for (final w in text.split(' ')) {
      await Future.delayed(const Duration(milliseconds: 25));
      yield '$w ';
    }
  }
}

class InferenceController extends ChangeNotifier {
  final rag = Rag();
  final _mock = MockBackend();
  late final List<LlmBackend> _order = Platform.isAndroid
      ? [NativeLlamaBackend(), OllamaBackend()]
      : [OllamaBackend(), NativeLlamaBackend()];
  late LlmBackend active = _mock;

  Future<void> init() async {
    await rag.load();
    await refresh();
  }

  Future<void> refresh() async {
    active = _mock;
    for (final b in _order) {
      if (await b.available()) {
        active = b;
        break;
      }
    }
    notifyListeners();
  }

  Stream<String> ask(String q) async* {
    final ctx = rag.search(q).map((c) => c.text).join('\n');
    final sys = 'You are GramVidya, a patient tutor for rural and tribal college students. '
        'Answer in ${langEnglish[appLang.value]} using short, simple sentences and one everyday example. '
        'Use these notes when relevant:\n$ctx\nIf you are unsure, say so.';
    try {
      yield* active.generate(sys, q, context: ctx);
    } catch (_) {
      active = _mock;
      notifyListeners();
      yield* _mock.generate(sys, q, context: ctx);
    }
  }
}
