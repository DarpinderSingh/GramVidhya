/// SAMPLE DATA for demonstration. Verify amounts, caps and eligibility on scholarships.gov.in and update this list each year.
class Scheme {
  const Scheme(this.name, this.body, this.levels, this.note,
      {this.groups = const {}, this.incomeCapLakh, this.girlsOnly = false, this.pwdOnly = false});
  final String name, body, note;
  final Set<String> levels, groups; // empty groups = open to all
  final double? incomeCapLakh;
  final bool girlsOnly, pwdOnly;
}

const schemes = <Scheme>[
  Scheme('Post Matric Scholarship for ST', 'Ministry of Tribal Affairs (NSP)', {'UG', 'PG', 'Diploma'},
      'Course fees and maintenance for Scheduled Tribe students.', groups: {'ST'}, incomeCapLakh: 2.5),
  Scheme('Post Matric Scholarship for SC', 'Ministry of Social Justice (NSP)', {'UG', 'PG', 'Diploma'},
      'Fees and maintenance for Scheduled Caste students.', groups: {'SC'}, incomeCapLakh: 2.5),
  Scheme('PM YASASVI', 'Ministry of Social Justice (NSP)', {'UG', 'PG', 'Diploma'},
      'For OBC, EBC and DNT students.', groups: {'OBC'}, incomeCapLakh: 2.5),
  Scheme('Merit-cum-Means Scholarship', 'Ministry of Minority Affairs (NSP)', {'UG', 'PG', 'Diploma'},
      'Professional and technical courses for notified minorities.', groups: {'Minority'}, incomeCapLakh: 2.5),
  Scheme('Central Sector Scholarship for College Students', 'Dept. of Higher Education (NSP)', {'UG', 'PG'},
      'Needs a high Class 12 board percentile.', incomeCapLakh: 4.5),
  Scheme('AICTE Pragati', 'AICTE', {'UG', 'Diploma'}, 'Girls in AICTE-approved technical programmes.',
      incomeCapLakh: 8, girlsOnly: true),
  Scheme('AICTE Saksham', 'AICTE', {'UG', 'Diploma'}, 'Students with disabilities in technical programmes.',
      incomeCapLakh: 8, pwdOnly: true),
];

List<Scheme> matchSchemes({required String group, required String level, required double incomeLakh, bool girl = false, bool pwd = false}) =>
    schemes
        .where((s) =>
            s.levels.contains(level) &&
            (s.groups.isEmpty || s.groups.contains(group)) &&
            (s.incomeCapLakh == null || incomeLakh <= s.incomeCapLakh!) &&
            (!s.girlsOnly || girl) &&
            (!s.pwdOnly || pwd))
        .toList();
