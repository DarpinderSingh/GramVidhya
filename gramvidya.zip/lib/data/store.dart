import 'dart:convert';
import 'package:hive_flutter/hive_flutter.dart';

/// Offline-first progress store. Events wait in a queue until an optional sync endpoint is configured.
class Store {
  static Box get _b => Hive.box('app');
  static bool done(String id) => _b.get('done_$id', defaultValue: false) as bool;
  static int get pending => (_b.get('q', defaultValue: <String>[]) as List).length;
  static Future<void> setDone(String id, bool v) async {
    await _b.put('done_$id', v);
    final q = List<String>.from(_b.get('q', defaultValue: <String>[]) as List)
      ..add(jsonEncode({'e': 'module', 'id': id, 'v': v, 't': DateTime.now().toIso8601String()}));
    await _b.put('q', q);
  }
}
