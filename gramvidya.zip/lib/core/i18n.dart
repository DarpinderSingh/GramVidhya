import 'package:flutter/foundation.dart';

final appLang = ValueNotifier<String>('en');
// Gondi and Santali: add entries here once translations are reviewed by native speakers.
const langNames = {'en': 'English', 'hi': 'हिन्दी', 'bn': 'বাংলা', 'te': 'తెలుగు', 'mr': 'मराठी', 'ta': 'தமிழ்'};
const langEnglish = {'en': 'English', 'hi': 'Hindi', 'bn': 'Bengali', 'te': 'Telugu', 'mr': 'Marathi', 'ta': 'Tamil'};
const langLocales = {'en': 'en-IN', 'hi': 'hi-IN', 'bn': 'bn-IN', 'te': 'te-IN', 'mr': 'mr-IN', 'ta': 'ta-IN'};

const Map<String, Map<String, String>> _s = {
  'en': {'nav_home': 'Home', 'nav_ask': 'Ask', 'nav_schol': 'Scholarships', 'nav_share': 'Share', 'offline': 'Offline ready', 'hint': 'Ask a doubt…'},
  'hi': {'nav_home': 'होम', 'nav_ask': 'पूछें', 'nav_schol': 'छात्रवृत्ति', 'nav_share': 'साझा करें', 'offline': 'ऑफ़लाइन तैयार', 'hint': 'अपना संदेह पूछें…'},
  'bn': {'nav_home': 'হোম', 'nav_ask': 'জিজ্ঞাসা', 'nav_schol': 'বৃত্তি', 'nav_share': 'শেয়ার', 'offline': 'অফলাইনে প্রস্তুত', 'hint': 'আপনার প্রশ্ন লিখুন…'},
  'te': {'nav_home': 'హోమ్', 'nav_ask': 'అడగండి', 'nav_schol': 'ఉపకారవేతనాలు', 'nav_share': 'షేర్', 'offline': 'ఆఫ్‌లైన్ సిద్ధం', 'hint': 'మీ సందేహం అడగండి…'},
  'mr': {'nav_home': 'मुख्यपृष्ठ', 'nav_ask': 'विचारा', 'nav_schol': 'शिष्यवृत्ती', 'nav_share': 'शेअर', 'offline': 'ऑफलाइन तयार', 'hint': 'तुमची शंका विचारा…'},
  'ta': {'nav_home': 'முகப்பு', 'nav_ask': 'கேளுங்கள்', 'nav_schol': 'உதவித்தொகை', 'nav_share': 'பகிர்', 'offline': 'ஆஃப்லைன் தயார்', 'hint': 'உங்கள் சந்தேகத்தைக் கேளுங்கள்…'},
};
String tr(String k) => _s[appLang.value]?[k] ?? _s['en']![k] ?? k;
