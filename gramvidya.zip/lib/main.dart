import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'ai/inference_controller.dart';
import 'core/i18n.dart';
import 'screens/chat.dart';
import 'screens/home.dart';
import 'screens/scholarships.dart';
import 'screens/share.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  await Hive.openBox('app');
  final ai = InferenceController();
  await ai.init();
  runApp(GramVidyaApp(ai: ai));
}

class GramVidyaApp extends StatelessWidget {
  const GramVidyaApp({super.key, required this.ai});
  final InferenceController ai;
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<String>(
        valueListenable: appLang,
        builder: (_, __, ___) => MaterialApp(
          title: 'GramVidya AI',
          debugShowCheckedModeBanner: false,
          theme: ThemeData.dark(useMaterial3: true).copyWith(
            scaffoldBackgroundColor: Colors.black,
            colorScheme: const ColorScheme.dark(
                primary: Color(0xFF5FD0C4),
                secondary: Color(0xFFF4B41A),
                surface: Color(0xFF0C1010)),
          ),
          home: Shell(ai: ai),
        ),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key, required this.ai});
  final InferenceController ai;
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int i = 0;
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: IndexedStack(index: i, children: [
            HomeScreen(ai: widget.ai),
            ChatScreen(ai: widget.ai),
            const ScholarshipScreen(),
            ShareScreen(ai: widget.ai),
          ]),
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: i,
          onDestinationSelected: (v) => setState(() => i = v),
          destinations: [
            NavigationDestination(icon: const Icon(Icons.home), label: tr('nav_home')),
            NavigationDestination(icon: const Icon(Icons.chat), label: tr('nav_ask')),
            NavigationDestination(icon: const Icon(Icons.school), label: tr('nav_schol')),
            NavigationDestination(icon: const Icon(Icons.share), label: tr('nav_share')),
          ],
        ),
      );
}
