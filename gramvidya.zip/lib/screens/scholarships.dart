import 'package:flutter/material.dart';
import '../data/scholarships.dart';

class ScholarshipScreen extends StatefulWidget {
  const ScholarshipScreen({super.key});
  @override
  State<ScholarshipScreen> createState() => _ScholState();
}

class _ScholState extends State<ScholarshipScreen> {
  String group = 'ST', level = 'UG';
  double income = 2;
  bool girl = false, pwd = false;

  @override
  Widget build(BuildContext context) {
    final r = matchSchemes(group: group, level: level, incomeLakh: income, girl: girl, pwd: pwd);
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Scholarship matcher', style: Theme.of(context).textTheme.headlineSmall),
      const Text('Sample data. Confirm on scholarships.gov.in before applying.'),
      Row(children: [
        const Text('Group  '),
        DropdownButton<String>(
            value: group,
            items: ['General', 'SC', 'ST', 'OBC', 'Minority'].map((g) => DropdownMenuItem(value: g, child: Text(g == 'ST' ? 'ST (Tribal)' : g))).toList(),
            onChanged: (v) => setState(() => group = v!)),
        const SizedBox(width: 24),
        const Text('Level  '),
        DropdownButton<String>(
            value: level,
            items: ['UG', 'PG', 'Diploma'].map((g) => DropdownMenuItem(value: g, child: Text(g))).toList(),
            onChanged: (v) => setState(() => level = v!)),
      ]),
      Text('Family income: up to ₹${income.toStringAsFixed(1)} lakh a year'),
      Slider(value: income, min: 0, max: 10, divisions: 20, onChanged: (v) => setState(() => income = v)),
      SwitchListTile(title: const Text('Female student'), value: girl, onChanged: (v) => setState(() => girl = v)),
      SwitchListTile(title: const Text('Person with disability'), value: pwd, onChanged: (v) => setState(() => pwd = v)),
      const Divider(),
      if (r.isEmpty) const Text('No match in the offline list. Try a higher income or another group.'),
      for (final s in r) Card(child: ListTile(title: Text(s.name), subtitle: Text('${s.body}\n${s.note}'), isThreeLine: true)),
    ]);
  }
}
