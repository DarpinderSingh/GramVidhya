import 'package:flutter/material.dart';
import '../ai/inference_controller.dart';
import '../core/i18n.dart';
import '../data/store.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.ai});
  final InferenceController ai;
  @override
  State<HomeScreen> createState() => _HomeState();
}

class _HomeState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [
          Text('GramVidya AI', style: Theme.of(context).textTheme.headlineMedium),
          const Spacer(),
          DropdownButton<String>(
            value: appLang.value,
            items: langNames.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value))).toList(),
            onChanged: (v) => appLang.value = v!,
          ),
        ]),
        Card(
          child: ListTile(
            leading: const Icon(Icons.offline_bolt),
            title: Text(tr('offline')),
            subtitle: Text('AI: ${widget.ai.active.name}\n${Store.pending} progress events waiting to sync'),
            isThreeLine: true,
            trailing: IconButton(
                icon: const Icon(Icons.refresh),
                onPressed: () async {
                  await widget.ai.refresh();
                  setState(() {});
                }),
          ),
        ),
        for (final m in widget.ai.rag.chunks)
          CheckboxListTile(
            value: Store.done(m.id),
            title: Text(m.subject),
            subtitle: Text(m.text, maxLines: 2, overflow: TextOverflow.ellipsis),
            onChanged: (v) async {
              await Store.setDone(m.id, v!);
              setState(() {});
            },
          ),
      ]);
}
