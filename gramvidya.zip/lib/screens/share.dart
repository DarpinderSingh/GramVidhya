import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import '../ai/inference_controller.dart';
import '../p2p/share_service.dart';

class ShareScreen extends StatefulWidget {
  const ShareScreen({super.key, required this.ai});
  final InferenceController ai;
  @override
  State<ShareScreen> createState() => _ShareState();
}

class _ShareState extends State<ShareScreen> {
  final _s = ShareService();
  final _peers = <String, Peer>{};
  StreamSubscription? _sub;
  Peer? _sel;
  List<Map> _files = [];
  bool _hosting = false;
  String _status = 'Connect both devices to the same hotspot or Wi-Fi Direct group.';

  Future<void> _host() async {
    await _s.host(Platform.localHostname);
    final d = await _s.dir();
    setState(() {
      _hosting = true;
      _status = 'Sharing every file in:\n${d.path}';
    });
  }

  void _find() {
    _sub?.cancel();
    _sub = _s.discover().listen((p) => setState(() => _peers[p.ip] = p));
    setState(() => _status = 'Looking for nearby devices…');
  }

  Future<void> _open(Peer p) async {
    final f = await _s.manifest(p);
    setState(() {
      _sel = p;
      _files = f;
    });
  }

  Future<void> _get(String name) async {
    setState(() => _status = 'Downloading $name…');
    final f = await _s.download(_sel!, name);
    if (name.endsWith('.json')) widget.ai.rag.addJson(await f.readAsString());
    setState(() => _status = 'Saved $name');
  }

  @override
  void dispose() {
    _sub?.cancel();
    _s.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
        Text('Share content', style: Theme.of(context).textTheme.headlineSmall),
        Text(_status),
        const SizedBox(height: 8),
        Wrap(spacing: 8, children: [
          FilledButton.icon(onPressed: _hosting ? null : _host, icon: const Icon(Icons.upload), label: const Text('Share my files')),
          OutlinedButton.icon(onPressed: _find, icon: const Icon(Icons.radar), label: const Text('Find nearby')),
        ]),
        for (final p in _peers.values) ListTile(leading: const Icon(Icons.devices), title: Text(p.name), subtitle: Text(p.ip), onTap: () => _open(p)),
        for (final f in _files)
          ListTile(
            title: Text(f['name']),
            subtitle: Text('${((f['size'] as int) / 1e6).toStringAsFixed(1)} MB'),
            trailing: IconButton(icon: const Icon(Icons.download), onPressed: () => _get(f['name'])),
          ),
      ]);
}
