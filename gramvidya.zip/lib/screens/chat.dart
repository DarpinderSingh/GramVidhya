import 'package:flutter/material.dart';
import '../ai/inference_controller.dart';
import '../core/i18n.dart';
import '../voice/voice_service.dart';

class _Msg {
  _Msg(this.text, this.user);
  String text;
  final bool user;
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.ai});
  final InferenceController ai;
  @override
  State<ChatScreen> createState() => _ChatState();
}

class _ChatState extends State<ChatScreen> {
  final _c = TextEditingController();
  final _v = VoiceService();
  final _msgs = <_Msg>[];
  bool _busy = false, _rec = false;

  Future<void> _send([String? t]) async {
    final q = (t ?? _c.text).trim();
    if (q.isEmpty || _busy) return;
    _c.clear();
    setState(() {
      _msgs..add(_Msg(q, true))..add(_Msg('', false));
      _busy = true;
    });
    await for (final tok in widget.ai.ask(q)) {
      setState(() => _msgs.last.text += tok);
    }
    setState(() => _busy = false);
    _v.speak(_msgs.last.text, appLang.value);
  }

  Future<void> _mic() async {
    if (_rec) {
      final text = await _v.stop(appLang.value);
      setState(() => _rec = false);
      _send(text);
    } else {
      setState(() => _rec = true);
      await _v.start(appLang.value, (t) => _c.text = t);
    }
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        Padding(
            padding: const EdgeInsets.all(8),
            child: Text(widget.ai.active.name, style: Theme.of(context).textTheme.bodySmall)),
        Expanded(
          child: ListView(padding: const EdgeInsets.all(12), children: [
            for (final m in _msgs)
              Align(
                alignment: m.user ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  margin: const EdgeInsets.symmetric(vertical: 4),
                  padding: const EdgeInsets.all(12),
                  constraints: const BoxConstraints(maxWidth: 560),
                  decoration: BoxDecoration(
                    color: m.user ? Theme.of(context).colorScheme.primary : Theme.of(context).colorScheme.surface,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Text(m.text.isEmpty ? '…' : m.text,
                      style: TextStyle(color: m.user ? Colors.black : null)),
                ),
              ),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.all(8),
          child: Row(children: [
            IconButton.filledTonal(
                onPressed: _mic, icon: Icon(_rec ? Icons.stop : Icons.mic), tooltip: 'Voice'),
            const SizedBox(width: 8),
            Expanded(child: TextField(controller: _c, onSubmitted: _send, decoration: InputDecoration(hintText: tr('hint'), border: const OutlineInputBorder()))),
            const SizedBox(width: 8),
            IconButton.filled(onPressed: () => _send(), icon: const Icon(Icons.send)),
          ]),
        ),
      ]);
}
