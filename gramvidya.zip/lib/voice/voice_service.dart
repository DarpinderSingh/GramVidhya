import 'dart:io';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:speech_to_text/speech_to_text.dart';
import '../core/i18n.dart';

/// Android/macOS: system recogniser (on-device when the language pack is installed).
/// Windows/Linux: records 16 kHz WAV and runs the whisper.cpp CLI locally.
class VoiceService {
  final _stt = SpeechToText();
  final _rec = AudioRecorder();
  final _tts = FlutterTts();
  String _last = '', _wav = '';
  final _bin = Platform.environment['GRAMVIDYA_WHISPER_BIN'] ?? 'whisper-cli';
  final _model = Platform.environment['GRAMVIDYA_WHISPER_MODEL'] ?? 'ggml-base.bin';
  bool get _system => Platform.isAndroid || Platform.isIOS || Platform.isMacOS;

  Future<void> start(String code, void Function(String) onText) async {
    if (_system) {
      _last = '';
      if (!await _stt.initialize()) return;
      await _stt.listen(
          localeId: langLocales[code]?.replaceAll('-', '_'),
          onResult: (r) {
            _last = r.recognizedWords;
            onText(_last);
          },
          listenOptions: SpeechListenOptions(onDevice: true));
    } else {
      if (!await _rec.hasPermission()) return;
      _wav = '${(await getTemporaryDirectory()).path}/q.wav';
      await _rec.start(const RecordConfig(encoder: AudioEncoder.wav, sampleRate: 16000, numChannels: 1), path: _wav);
    }
  }

  Future<String> stop(String code) async {
    if (_system) {
      await _stt.stop();
      return _last;
    }
    await _rec.stop();
    final r = await Process.run(_bin, ['-m', _model, '-f', _wav, '-l', code, '-nt']);
    return (r.stdout as String).trim();
  }

  Future<void> speak(String text, String code) async {
    try {
      await _tts.setLanguage(langLocales[code]!);
      await _tts.speak(text);
    } catch (_) {}
  }
}
